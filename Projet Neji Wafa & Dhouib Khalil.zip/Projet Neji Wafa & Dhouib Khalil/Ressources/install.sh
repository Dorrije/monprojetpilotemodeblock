#!/bin/sh

if ([ $# -lt 1 ]) then
echo  "--> !! Veuiller choisir -i pour l'installation ou -d pour la désinstallation"
echo
exit 0
fi


if ([ $1 = -i  ]) then
echo 
echo Cette application est réalisée par Dhouib Khalil et Neji Wafa
echo GL5 Group 2
echo 
echo "Donner le chemin du fichier .ko (exemple: ./tp2final-driver.ko)>"
read chaine
echo Chargement de module en cours..... 
sudo insmod "$chaine"
echo Module chargé.
echo

echo Création de noeud en cours....

if !( test -e /dev/mondevice) then
sudo mknod /dev/mondevice b 254 0
sudo chmod 666 /dev/mondevice
fi

echo noeud crée avec succès
echo
fi


if ([ $1 = -d  ]) then
echo 
echo "Donner le chemin du fichier .ko (exemple: ./tp2final-driver.ko)>"
read chaine
echo déchargement de module en cours..... 
sudo rmmod "$chaine"
echo Module déchargé.
fi





